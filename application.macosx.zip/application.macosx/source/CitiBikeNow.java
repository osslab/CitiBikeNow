import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.List; 
import java.util.Arrays; 
import de.fhpotsdam.unfolding.*; 
import de.fhpotsdam.unfolding.geo.*; 
import de.fhpotsdam.unfolding.utils.*; 
import de.fhpotsdam.unfolding.providers.*; 
import de.fhpotsdam.unfolding.marker.*; 
import de.fhpotsdam.unfolding.marker.MarkerManager; 
import de.fhpotsdam.unfolding.marker.SimplePointMarker; 
import de.fhpotsdam.unfolding.data.Feature; 
import de.fhpotsdam.unfolding.data.PointFeature; 
import de.fhpotsdam.unfolding.data.GeoJSONReader; 
import de.fhpotsdam.unfolding.events.ZoomMapEvent; 
import de.fhpotsdam.unfolding.geo.Location; 
import de.fhpotsdam.unfolding.marker.SimplePointMarker; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class CitiBikeNow extends PApplet {

/**
 * An application with a basic interactive map. You can zoom and pan the map.
 */


















boolean record;


PFont BoldFont;
UnfoldingMap map;
MarkerManager markerManager;
StationPointMarker bikeMarker;
List<Marker> bikeMarkers;

PVector rotateCenter = new PVector(350, 250);
Location tischLocation = new Location(40.7294250f, -73.9937070f);
Location mapTopLeftBoarder;
Location mapBottomRightBorder;


Timer timer;

String executionTime;

File folder;
File[] listOfFiles;

int fileNumber = 0;
int fileTotalNumber = 0;

int currentZoom = 14;


float maxLat;
float minLat;
float maxLon;
float minLon;

PGraphics pg;

public void setup() {
  size(displayWidth,displayHeight); // ON SCREEN SIZE
  //pg = createGraphics(4724, 5906); // PRINT SIZE
  
  //folder = new File("/Users/suhongseo/Documents/data-processing/CitiBikeNowPoster/data/con/");
  //listOfFiles = folder.listFiles();
  //fileTotalNumber = listOfFiles.length;

  

  
  setGeoJSON();
  setBikeMarker();


  BoldFont = createFont("Tahoma-Bold", 14);
  textFont(BoldFont);
  
  SimplePointMarker tischMarker = new SimplePointMarker(tischLocation);
 
  
  tischMarker.setColor(color(255, 0, 0, 100));

 
  
  
  map = new UnfoldingMap(this, new StamenMapProvider.Toner());
  map.zoomToLevel(currentZoom);
  map.panTo(tischLocation);  
  
  
  MapUtils.createDefaultEventDispatcher(this, map);
  
  
  
  
  
  
  map.addMarkers(tischMarker);
  map.addMarkers(bikeMarkers);
  
  markerManager = map.getDefaultMarkerManager();
  
  
  mapTopLeftBoarder = map.getTopLeftBorder();
  mapBottomRightBorder = map.getBottomRightBorder();
  
  maxLat = mapTopLeftBoarder.getLat();
  maxLon = mapTopLeftBoarder.getLon();
  minLat = mapBottomRightBorder.getLat();
  minLon = mapBottomRightBorder.getLon();
  
  println(maxLat + ", " + maxLon);
  println(minLat + ", " + minLon);
  
  
  
  
  timer = new Timer(60000); //1min to refresh
  timer.start();  
 
}

public void draw() {

  
  
  if (timer.isFinished()) {
    markerManager.clearMarkers();
    setGeoJSON();
    setBikeMarker();
    map.addMarkers(bikeMarkers);

    timer.start();
    println(executionTime);
  } 


    //

  map.draw();
  
  
  textSize(14);
  fill(255,255,255, 255);
  text("Updated Time : ", 10, height-40);
  text(executionTime, 10,height-25);   
 

}

public void setGeoJSON(){

  
  String jsonUrl = "";
  jsonUrl = "http://www.citibikenyc.com/stations/json";
  
  
  println(jsonUrl);
  JSONObject jsonObject = loadJSONObject(jsonUrl);
  JSONArray citiBikeJSONArray = jsonObject.getJSONArray("stationBeanList");
  JSONObject geoCitiBikes = new JSONObject(); 
  JSONArray featureList = new JSONArray();
  JSONObject station = new JSONObject();
   
  executionTime =  jsonObject.getString("executionTime");
 

   
  
  for(int i = 0; i < citiBikeJSONArray.size(); i++){
    station = citiBikeJSONArray.getJSONObject(i);
    
    JSONObject point = new JSONObject();
    point.setString("type", "Point");
    
    JSONArray coord = new JSONArray();
    coord.append(station.getFloat("longitude"));
    coord.append(station.getFloat("latitude"));
    
    
    point.setJSONArray("coordinates", coord);
    JSONObject properties = new JSONObject();
    properties.setString("name", station.getString("stationName"));
    properties.setInt("totalDocks", station.getInt("totalDocks"));
    properties.setInt("availableDocks", station.getInt("availableDocks"));
    properties.setInt("availableBikes", station.getInt("availableBikes"));
 
    
    JSONObject feature = new JSONObject();
    
    feature.setJSONObject("geometry", point);
    feature.setJSONObject("properties", properties); 
    feature.setString("type", "Feature");
    featureList.append(feature);
    geoCitiBikes.setJSONArray("features", featureList);
    
  }

   geoCitiBikes.setString("type", "FeatureCollection"); 
   saveJSONObject(geoCitiBikes, "data/new.json");


}

public void mousePressed(){
  record = true;

  if (mouseEvent.getClickCount()==2) {
    currentZoom++;
  }
  




  
}
  public void keyPressed() {
    rotateCenter = new PVector(mouseX, mouseY);

    // Inner rotate (i.e. map) works with both, P2D and GLGraphics
    map.mapDisplay.setInnerTransformationCenter(rotateCenter);
    if (key == 'r') {
      map.rotate(-PI / 8);
    } else if (key == 'l') {
      map.rotate(PI / 8);
    }
    else if (key == '-'){
      currentZoom--;
      map.zoomToLevel(currentZoom);
      map.panTo(map.getCenter());
    }
    else if (key == '+'){
      currentZoom++;
      map.zoomToLevel(currentZoom);
      map.panTo(map.getCenter());
    }

  }
  


public void setBikeMarker(){

   List<Feature> stations = GeoJSONReader.loadData(this, "data/new.json");
   bikeMarkers = new ArrayList<Marker>();
   bikeMarkers = MapUtils.createSimpleMarkers(stations);
   
   

  for(Feature feature :   stations){
    PointFeature pointFeature = (PointFeature) feature;
    //println(pointFeature.getProperties());
     bikeMarker = new StationPointMarker(pointFeature.getLocation(), pointFeature.getProperties());
    
    
    
    
    //bikeMarker.setColor(color(0, 0, 255, 100));
    //bikeMarker.text(pointFeature.getProperty("name"));
    
    
    bikeMarkers.add(bikeMarker);
    //println(pointFeature.getLocation().toString());
  }  


}


public void saveTimestamped(PImage im) { 

 int s = second(); // VALUES FROM 0 - 59

 int mi = minute(); // VALUES FROM 0 - 59

 int h = hour(); // VALUES FROM 0 - 23

 int d = day(); // VALUES FROM 1 - 31

 int m = month(); // VALUES FROM 1 - 12

 int y = year(); // 2003, 2004, 2005, ETC.

 

 String filename = y+"-"+m+"-"+d+"-"+h+"-"+mi+"-"+s+".tiff"; 

 im.save(filename); 

 

}


 
 
 
public class StationPointMarker extends SimplePointMarker {
 
 
  
  public StationPointMarker(Location location) {
    super(location);
  }
 
   public StationPointMarker(Location location, HashMap<String, Object> properties) {
    super(location, properties);

  }
 
  public void draw(PGraphics pg, float x, float y) {
    

    pg.pushStyle();
    pg.noStroke();
    int availableBikes = (Integer) properties.get("availableBikes");
    
    if(availableBikes<5)pg.fill(255, 201, 33, 100*(1+1.5f*(5-availableBikes)/5));
    else if (availableBikes>=5 && availableBikes<20) pg.fill(36,234,153, 100*(1+((availableBikes%10)*0.1f)));
    else if (availableBikes >= 20) pg.fill(131,39,129, 100*(1+((availableBikes%10)*0.1f)));
    pg.ellipse(x, y, 18+availableBikes*0.8f,18+availableBikes*0.8f);
    pg.textSize(14);
    pg.fill(255, 255, 255, 255);
    pg.text(properties.get("availableBikes").toString(), x-textWidth(properties.get("availableBikes").toString())/2, y+6);
    
    
    pg.popStyle();
  }
}
class Timer {
 
  int savedTime; // When Timer started
  int totalTime; // How long Timer should last
  
  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }
  
  // Starting the timer
  public void start() {
    // When the timer starts it stores the current time in milliseconds.
    savedTime = millis(); 
  }
  
  // The function isFinished() returns true if 5,000 ms have passed. 
  // The work of the timer is farmed out to this method.
  public boolean isFinished() { 
    // Check how much time has passed
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--stop-color=#cccccc", "CitiBikeNow" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
